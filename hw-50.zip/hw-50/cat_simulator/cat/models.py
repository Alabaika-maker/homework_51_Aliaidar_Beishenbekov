from django.db import models

class Cat(models.Model):
    name = models.CharField(max_length=100)
    age = models.IntegerField(default=1)
    fullness = models.IntegerField(default=40)
    happiness = models.IntegerField(default=40)
    sleeping = models.BooleanField(default=False)
    
    def feed(self):
        if not self.sleeping:
            self.fullness = min(self.fullness + 15, 100)
            self.happiness = min(self.happiness + 5, 100)
            if self.fullness > 100:
                self.happiness = max(self.happiness - 30, 0)
                
    def play(self):
        if not self.sleeping:
            import random
            self.fullness = max(self.fullness - 10, 0)
            if random.choice([True, False, False]):  # 1 к 3 шанс
                self.happiness = 0
            else:
                self.happiness = min(self.happiness + 15, 100)
        else:
            self.sleeping = False
            self.happiness = max(self.happiness - 5, 0)
    
    def sleep(self):
        self.sleeping = True

    def get_avatar(self):
        if self.happiness < 33:
            return 'cat/sad.png'
        elif self.happiness < 66:
            return 'cat/neutral.png'
        else:
            return 'cat/happy.png'

    def __str__(self):
        return self.name
